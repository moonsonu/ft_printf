#ifndef CHEAT_H
# include <stdint.h>
#endif
